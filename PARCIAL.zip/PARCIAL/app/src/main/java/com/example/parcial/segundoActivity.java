package com.example.parcial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class segundoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segundo);

        TextView nombre2TextView = findViewById(R.id.Nombre2);
        TextView edad2TextView = findViewById(R.id.Edad2);
        TextView Materia2TextView = findViewById(R.id.Materia2);

        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String edad = intent.getStringExtra("edad");
        String materia = intent.getStringExtra("materia");

        nombre2TextView.setText("Nombre: " + nombre);
        edad2TextView.setText("Edad: " + edad);
        Materia2TextView.setText("Materia: " + materia);
    }
}
